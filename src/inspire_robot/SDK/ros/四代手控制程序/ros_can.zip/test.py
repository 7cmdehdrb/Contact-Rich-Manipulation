#!/usr/bin/env python3

import rospy
import time
import logging
import os
from inspire_hand.srv import GetAngleAct, SetAngle

RED = "\033[91m"
RESET = "\033[0m"

def main():
    rospy.init_node('read_write_loop', anonymous=True)

    # 设置日志文件（使用绝对路径）
    log_dir = os.path.expanduser("~/ros_can")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    log_filename = os.path.join(log_dir, "angle_log.txt")
    
    # 配置日志系统
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    
    # 文件处理器
    file_handler = logging.FileHandler(log_filename, mode='a')
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
    logger.addHandler(console_handler)

    logging.info(f"Logging initialized, writing to: {log_filename}")

    # 等待两个服务
    rospy.wait_for_service('/inspire_hand/GetAngleAct')
    rospy.wait_for_service('/inspire_hand/SetAngle')

    try:
        get_angle_srv = rospy.ServiceProxy('/inspire_hand/GetAngleAct', GetAngleAct)
        set_angle_srv = rospy.ServiceProxy('/inspire_hand/SetAngle', SetAngle)

        rate = rospy.Rate(5)  # 5Hz
        angles = [0, 0, 0, 0, 1000, 1000]  
        increment = 200
        max_angle = 1000
        count = 0
        max_iterations = 0  # 无限循环

        while not rospy.is_shutdown() and (max_iterations <= 0 or count < max_iterations):
            # 读取当前角度（读操作）
            try:
                start_time = time.time()
                response = get_angle_srv()
                end_time = time.time()
                latency = end_time - start_time

                # 打印到控制台
                logging.info("Current angles: {}".format(response.curangle))
                logging.info("Get response latency: {:.6f} seconds".format(latency))

                # 判断角度是否大于1000
                for idx, angle in enumerate(response.curangle): 
                    if angle > 1000:
                        log_msg = "Angle index {} exceeds 1000 with value: {}".format(idx, angle)
                        logging.warning(log_msg)  # 记录日志文件
                        print(RED + "WARNING: " + log_msg + RESET)  

            except rospy.ServiceException as e:
                logging.error("Failed to call GetAngleAct service: {}".format(e))  # 记录错误日志
                continue  # 如果服务调用失败，继续下一个循环

            new_angles = angles.copy()
            for i in range(4):
                new_angles[i] += increment
                if new_angles[i] > max_angle:
                    new_angles[i] = 0

            angles = new_angles  # 更新角度数组

            try:
                set_response = set_angle_srv(*angles)  # 传递所有6个角度
                logging.info("Set angles to: {}".format(angles))  # 记录设置的角度到日志

            except rospy.ServiceException as e:
                logging.error("Failed to call SetAngle service: {}".format(e))  # 记录错误日志

            count += 1
            rate.sleep()

    except rospy.ROSInterruptException:
        pass
    finally:
        # 关闭日志处理器
        for handler in logger.handlers:
            handler.close()
            logger.removeHandler(handler)

if __name__ == "__main__":
    main()
