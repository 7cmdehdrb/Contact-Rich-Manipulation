/**
Copyright (c) 2014, Konstantinos Chatzilygeroudis
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
    in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived
    from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,
BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
**/

#ifndef ROBOTICSGROUP_UPATRAS_GAZEBO_PLUGINS__MIMIC_JOINT_PLUGIN_HPP_
#define ROBOTICSGROUP_UPATRAS_GAZEBO_PLUGINS__MIMIC_JOINT_PLUGIN_HPP_

#include <memory>

#include <control_toolbox/pid_ros.hpp>

#include <gazebo/common/Plugin.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo_ros/node.hpp>

namespace gazebo {

    class MimicJointPlugin : public ModelPlugin {
      public:
        MimicJointPlugin();
        ~MimicJointPlugin() override;
        void Load(physics::ModelPtr _parent, sdf::ElementPtr _sdf) override;

      private:
        void UpdateChild();

        gazebo_ros::Node::SharedPtr ros_node_;

        // Parameters
        double multiplier_, offset_, sensitiveness_, max_effort_;

        // PID controller if needed
        std::unique_ptr<control_toolbox::PidROS> pid_;

        // Pointers to the joints
        physics::JointPtr joint_, mimic_joint_;

        // Pointer to the world
        physics::WorldPtr world_;

        // Pointer to the update event connection
        event::ConnectionPtr update_connection_;
    };

}

#endif  // ROBOTICSGROUP_UPATRAS_GAZEBO_PLUGINS__MIMIC_JOINT_PLUGIN_HPP_
